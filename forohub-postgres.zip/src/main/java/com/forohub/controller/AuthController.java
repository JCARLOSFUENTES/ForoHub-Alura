package com.forohub.controller;

import com.forohub.model.Usuario;
import com.forohub.repository.UsuarioRepository;
import com.forohub.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final UsuarioRepository repository;
    private final BCryptPasswordEncoder encoder;

    public AuthController(UsuarioRepository repository, BCryptPasswordEncoder encoder) {
        this.repository = repository;
        this.encoder = encoder;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Usuario usuario) {
        if (repository.findByUsername(usuario.getUsername()).isPresent()) {
            return ResponseEntity.status(409).body("Usuario ya existe");
        }
        usuario.setPassword(encoder.encode(usuario.getPassword()));
        repository.save(usuario);
        return ResponseEntity.status(201).body("Usuario registrado");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Usuario usuario) {
        return repository.findByUsername(usuario.getUsername())
                .filter(u -> encoder.matches(usuario.getPassword(), u.getPassword()))
                .map(u -> ResponseEntity.ok(Map.of("token", JwtUtil.generarToken(u.getUsername()))))
                .orElse(ResponseEntity.status(401).body("Credenciales inválidas"));
    }
}
