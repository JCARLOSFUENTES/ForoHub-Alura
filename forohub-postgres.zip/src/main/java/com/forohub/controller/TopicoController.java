package com.forohub.controller;

import com.forohub.model.Topico;
import com.forohub.repository.TopicoRepository;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Optional;

@RestController
@RequestMapping("/topicos")
public class TopicoController {

    private final TopicoRepository repository;

    public TopicoController(TopicoRepository repository) {
        this.repository = repository;
    }

    @PostMapping
    @Transactional
    public ResponseEntity<?> crear(@RequestBody @Valid Topico topico) {
        if (repository.existsByTituloAndMensaje(topico.getTitulo(), topico.getMensaje())) {
            return ResponseEntity.status(409).body("Tópico duplicado");
        }
        topico.setFechaCreacion(LocalDateTime.now());
        Topico saved = repository.save(topico);
        return ResponseEntity.status(201).body(saved);
    }

    @GetMapping
    public ResponseEntity<Page<Topico>> listar(@PageableDefault(size = 10, sort = "fechaCreacion") Pageable pageable) {
        return ResponseEntity.ok(repository.findAll(pageable));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> detalle(@PathVariable Long id) {
        Optional<Topico> topico = repository.findById(id);
        return topico.<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(404).body("Tópico no encontrado"));
    }

    @PutMapping("/{id}")
    @Transactional
    public ResponseEntity<?> actualizar(@PathVariable Long id, @RequestBody Topico nuevo) {
        return repository.findById(id).map(t -> {
            t.setTitulo(nuevo.getTitulo());
            t.setMensaje(nuevo.getMensaje());
            t.setAutor(nuevo.getAutor());
            t.setCurso(nuevo.getCurso());
            t.setStatus(nuevo.getStatus());
            return ResponseEntity.ok(repository.save(t));
        }).orElse(ResponseEntity.status(404).body("Tópico no encontrado"));
    }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.status(404).body("Tópico no encontrado");
        }
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
